# Auto Grader Application

## Overview

This is a desktop application built with Python and Tkinter that provides automated grading functionality for assignments. The system offers dual grading methods (keyword-based with typed keywords and AI-assisted with custom instructions), and includes AI-generated text detection capabilities using machine learning models.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **GUI Framework**: Tkinter-based desktop application
- **Design Pattern**: Single-window interface with button-driven interactions
- **User Flow**: Sequential workflow - upload assignment → select grading method → enter keywords/instructions → grade → view results
- **Text Display**: ScrolledText widget for multi-line text input/output
- **Grading Method Selection**: Radio buttons for choosing between keyword-based and AI-assisted grading

### Grading Methods
- **Keyword-based Grading**: Fast, simple keyword matching with typed keywords
  - Educators type keywords with point values (e.g., "photosynthesis:10, chlorophyll:5")
  - Checks if keywords appear in student text
  - Awards points based on keyword presence
  - Generates detailed reports with download options (TXT and PDF formats)
  - Shows results in messagebox with automatic report window
  - Ideal for objective, keyword-focused assessments
- **AI-Assisted Grading**: Comprehensive text quality assessment using SmolLM2-360M-Instruct
  - Uses HuggingFace's SmolLM2 lightweight language model for evaluation
  - Educators provide custom grading instructions describing evaluation criteria and scoring
  - AI evaluates student work based on instructions and provides a score out of 100
  - Displays letter grade (A-F) with percentage for easy interpretation
  - Model loads automatically on startup in background (downloads ~360MB on first run)
  - Generates detailed reports with download options (TXT and PDF formats)
  - Shows results in messagebox with automatic report window
  - Ideal for subjective, quality-focused assessments
- **Plagiarism Detection**: Web search and AI paraphrase detection
  - Uses DuckDuckGo search engine to find matching content online
  - Extracts key phrases from student text (ignoring common words)
  - Searches for exact phrase matches and keyword combinations
  - Uses AI model to detect paraphrased content without citations
  - Generates risk level assessment (LOW, LOW-MEDIUM, MEDIUM, HIGH)
  - Creates detailed reports with source URLs and matched content
  - Ideal for detecting copied or inadequately cited content

### Backend Architecture
- **Core Processing**: Event-driven architecture using Tkinter's command callbacks
- **Text Extraction Pipeline**: Multi-format document processing (PDF via PyPDF2)
- **ML Model Integration**: Pre-trained models loaded from joblib serialized files
- **Asynchronous Operations**: Threading with queue for long-running tasks

### Data Processing
- **Text Analysis**: NLTK for natural language processing (tokenization)
- **Feature Engineering**: TfidfVectorizer for text vectorization
- **ML Models**: 
  - Logistic Regression for classification tasks
  - SGDClassifier for scalable gradient descent learning
- **Model Persistence**: Joblib serialization for model and vectorizer artifacts

### AI Detection System
- **Purpose**: Identifies AI-generated content in student submissions
- **Approach**: Supervised learning using pre-trained classification models
- **Training Data**: Hugging Face dataset (ahmadreza13/human-vs-Ai-generated-dataset) with 3.6M examples
- **Detection Pipeline**: Text → Vectorization → Classification → Confidence score
- **Auto-Loading**: Model automatically loads on startup if previously trained
- **One-Time Training**: Users only need to train the model once; it persists across sessions
- **Progress Tracking**: Real-time progress bar and status updates during training
- **Non-Blocking UI**: Threading implementation keeps GUI responsive during model training


## External Dependencies

### Core Libraries
- **tkinter**: GUI framework (Python standard library)
- **PyPDF2**: PDF text extraction

### Machine Learning Stack
- **scikit-learn**: ML models (LogisticRegression, SGDClassifier) and text vectorization (TfidfVectorizer)
- **nltk**: Natural language toolkit for text preprocessing
- **joblib**: Model serialization and deserialization
- **datasets**: HuggingFace datasets library for training data loading
- **transformers**: HuggingFace transformers library for SmolLM2 model
- **torch**: PyTorch deep learning framework for model inference
- **reportlab**: PDF generation for AI grading reports
- **duckduckgo-search**: Web search for plagiarism detection

### External Services/Requirements
- **NLTK Data**: Punkt tokenizer models downloaded at runtime

### File Dependencies
- Pre-trained model file: `llm_model.joblib`
- Pre-trained vectorizer: `llm_vectorizer.joblib`
- Dependencies list: `auto-grader/requirements.txt`

### Project Structure
All Auto Grader application files are located in the `auto-grader/` directory:
- `auto-grader/auto grader.py` - Main application file
- `auto-grader/requirements.txt` - Python dependencies
- `auto-grader/setup.sh` - Automated setup script
- `auto-grader/README.md` - Documentation